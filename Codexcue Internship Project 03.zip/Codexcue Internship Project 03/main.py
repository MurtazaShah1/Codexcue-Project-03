class MusicPlayer:
    def __init__(self):
        self.song_list = []
        self.current_song_index = None
        self.is_playing = False

    def load_songs(self):
        """Load a predefined list of songs."""
        # Simulate loading songs
        self.song_list = ["song1.mp3", "song2.wav", "song3.mp3"]
        print(f"Loaded songs: {self.song_list}")

    def play_song(self, song_index):
        """Play the selected song."""
        if 0 <= song_index < len(self.song_list):
            self.current_song_index = song_index
            self.is_playing = True
            print(f"Now playing: {self.song_list[self.current_song_index]}")
        else:
            print("Error: Song index out of range.")

    def pause_song(self):
        """Pause the current song."""
        if self.is_playing:
            self.is_playing = False
            print("Song paused")
        else:
            print("Error: No song is currently playing.")

    def stop_song(self):
        """Stop the current song."""
        if self.is_playing:
            self.is_playing = False
            print("Song stopped")
        else:
            print("Error: No song is currently playing.")

    def next_song(self):
        """Play the next song in the list."""
        if self.song_list:
            if self.current_song_index is None:
                self.current_song_index = 0
            else:
                self.current_song_index = (self.current_song_index + 1) % len(self.song_list)
            self.play_song(self.current_song_index)
        else:
            print("Error: No songs to play.")

def main():
    player = MusicPlayer()
    player.load_songs()

    while True:
        print("\nMusic Player Menu")
        print("1. Play song")
        print("2. Pause song")
        print("3. Stop song")
        print("4. Next song")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            try:
                song_index = int(input("Enter the song index to play: "))
                player.play_song(song_index)
            except ValueError:
                print("Error: Please enter a valid number.")

        elif choice == '2':
            player.pause_song()

        elif choice == '3':
            player.stop_song()

        elif choice == '4':
            player.next_song()

        elif choice == '5':
            print("Exiting...")
            break

        else:
            print("Error: Invalid choice, please select a valid option.")

if __name__ == "__main__":
    main()
